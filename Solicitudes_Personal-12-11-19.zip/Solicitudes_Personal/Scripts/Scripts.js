function obtenerNombrePagina() {    // Función para obtener el nombre de la página, se eliminam la ruta y la extensión. 

    const pathCompleto = window.location.pathname;
    let nombrePagina = pathCompleto.split("/").pop();

        nombrePagina = nombrePagina.substring(0, nombrePagina.length - 5);
    
    return nombrePagina;

}

function fechaHoraIngreso() { // Funcion para mostrar la fecha y hora.

    var fechaActual = new Date();
    var anio = fechaActual.getFullYear();
    var mes = fechaActual.getMonth() + 1;
    var dia = fechaActual.getDate();

    var hora = fechaActual.getHours();
    var minutos = fechaActual.getMinutes();
    var segundos = fechaActual.getSeconds();

    var formatoTiempo = '' + ((hora > 12) ? hora - 12 : hora);

    if (hora == 0) 
        formatoTiempo = '12';
        formatoTiempo += ((minutos < 10) ? ':0' : ':') + minutos;
        formatoTiempo += ((segundos < 10) ? ':0' : ':') + segundos;
        formatoTiempo += (hora >= 12) ? ' P.M.' : ' A.M.'; 
    
    var fechaCompleta = anio + " / " + mes + " / " + dia + " - " + formatoTiempo;

    document.getElementById('horaFecha').innerHTML = fechaCompleta;
}

function mostrarSeccion() { // Función para ocultar y mostrar el contenido asociado a las opciones del menu.

    let paginaActual = obtenerNombrePagina();
    
    // console.log('llamado ' + paginaActual);
    
    switch (paginaActual) {

        case 'UA-Solicitud-Personal':

            document.getElementById('datosSolicitud').style.display = 'block';

        break;

        case 'RH-Revision-Solicitud':

            document.getElementById('datosSolicitud').style.display = 'block';

        break;

        case 'UA-Revision-Observaciones-RH':

            document.getElementById('datosSolicitud').style.display = 'block';

        break;

        case 'InforamcionSolicitud':

            document.getElementById('datosSolicitud').style.display = 'block';

        break;

        case 'RH-Publicar-Convocatoria':

            document.getElementById('datosSolicitud').style.display = 'block';

        break;

        case 'UA-Recepcion-Info-Candidatos':

            document.getElementById('solicitudPersonal').style.display = 'block';
            document.getElementById('informacionCandidatos').style.display = 'block';
       
        break;

        case 'UA-Seleccion-Candidato':

            document.getElementById('solicitudPersonal').style.display = 'block';
            document.getElementById('informacionCandidatos').style.display = 'block';

        break;

        case 'DAIA-Revision-Probatorios':

            document.getElementById('solicitudPersonal').style.display = 'block';
            document.getElementById('infoProbatoria').style.display = 'block';
        
        break;

        case 'UA-Consejo-Academico':

            document.getElementById('solicitudPersonal').style.display = 'block';
            document.getElementById('infoProbatoria').style.display = 'block';
            document.getElementById('consejoAcademico').style.display = 'block';

        break;

        case 'Division-Aprobacion':
            
            document.getElementById('solicitudPersonal').style.display = 'block';
            document.getElementById('aprobacionCandidato').style.display = 'block';
        
        break;

        case 'Vicerrectoria-Aprobacion':

            document.getElementById('solicitudPersonal').style.display = 'block';
            document.getElementById('aprobacionCandidato').style.display = 'block';
            
        break;

        case 'RH-Formalizacion-Contratacion':

            document.getElementById('solicitudPersonal').style.display = 'block';
            document.getElementById('aprobacionCandidato').style.display = 'block';
            
        break;
        
        default:

        }

}

function generarNumeroSolicitud() { // Funcion para generar un numero aleatorio de 6 posiciones.
	
    var numero_Solicitud = (Math.floor((Math.random() * 1000000 + 1)));
    
    window.sessionStorage.setItem("Num_Solicitud", numero_Solicitud);

    document.getElementById('numeroSolicitud').innerHTML = window.sessionStorage.getItem("Num_Solicitud");
   
}

function validarCamposRequeridos() { // Función para mostrar u ocultar los campos requeridos en caso de Sustitución o Suplencia.

    let plaza = document.getElementById('tipoPlazaSolicitada').value;
    
    if (plaza === 'Sustitucion' || plaza === 'Suplencia') {
        
        document.getElementById('etiqSustituye').style.display = 'table-cell';
        document.getElementById('txtSustituye').style.display = 'table-cell';
        document.getElementById('etiqNombreEmpleado').style.display = 'table-cell';
        document.getElementById('txtNombreEmpleado').style.display = 'table-cell';
        document.getElementById('etiqMotivo').style.display = 'table-cell';
        document.getElementById('txtMotivoSustitucion').style.display = 'table-cell';
        document.getElementById('tdRestablecerCampo').style.display = 'table-cell';
        document.getElementById('buscarNumeroEmpleado').disabled = false;
        document.getElementById('BuscarNombreEmpleado').disabled = false;

    } else if (plaza === 'Nueva Creacion' || plaza === 'Temporal') {
        
        document.getElementById('etiqSustituye').style.display = 'none';
        document.getElementById('txtSustituye').style.display = 'none';
        document.getElementById('etiqNombreEmpleado').style.display = 'none';
        document.getElementById('txtNombreEmpleado').style.display = 'none';
        document.getElementById('etiqMotivo').style.display = 'none';
        document.getElementById('txtMotivoSustitucion').style.display = 'none';
        document.getElementById('etiqMotivoEspecificado').style.display = 'none';
        document.getElementById('txtmotivoEspecificado').style.display = 'none';
        document.getElementById('icoRestablecer').style.display = 'none';
        document.getElementById('buscarNumeroEmpleado').disabled = true;
        document.getElementById('BuscarNombreEmpleado').disabled = true;
    }

}

function restablacerCriteriosBusqueda() { // Función para eliminar los valores de la búsqueda realizada.

    document.getElementById('nombreEmpleadoEncontrado').value = "";
    document.getElementById('numeroNominaEncontrado').value = "";
    document.getElementById('buscarNumeroEmpleado').value = "";
    document.getElementById('BuscarNombreEmpleado').value = "";

}

function especificarMotivo() { // Función para mostrar un campo en la forma para la captura de un motivo diferente a los que aparecen en el catálogo.

    let especificarMotivo = document.getElementById('motivoSustitucion').value;
    var motivoSustitucionEspecificado;

    if (especificarMotivo === 'Otro') {
        
        document.getElementById('etiqMotivoEspecificado').style.display = 'table-cell';
        document.getElementById('txtmotivoEspecificado').style.display = 'table-cell';
        motivoSustitucionEspecificado = document.getElementById('otroMotivoSustitucion').value;
        window.sessionStorage.setItem('Motivo_Sust_Especificado', motivoSustitucionEspecificado);

    } else {

        document.getElementById('etiqMotivoEspecificado').style.display = 'none';
        document.getElementById('txtmotivoEspecificado').style.display = 'none';
        motivoSustitucionEspecificado = "";
    }
}

function buscarEmpleado() {  // Función para simular la búsqueda de un empleado con base a su número de nómina o a su nombre.
    
    let aryEmpleados = ["Lourdes Terrazas Lopez", "Gabriel Medina Nava", "Eberto Fernandez Garcia"];
    let aryNumEmpleado = [10100, 10110, 10111];

    let numEmpleado = document.getElementById('buscarNumeroEmpleado').value;
    let nomEmpleado = document.getElementById('BuscarNombreEmpleado').value;

    if (numEmpleado != "" ) {

        if (numEmpleado === '10100') {

            document.getElementById('nombreEmpleadoEncontrado').value = aryEmpleados[0];
            document.getElementById('numeroNominaEncontrado').value = aryNumEmpleado[0];
            document.getElementById('buscarNumeroEmpleado').value = "";
            document.getElementById('BuscarNombreEmpleado').value = "";

        } 
        else if (numEmpleado === '10110') {
            document.getElementById('nombreEmpleadoEncontrado').value = aryEmpleados[1];
            document.getElementById('numeroNominaEncontrado').value = aryNumEmpleado[1];
            document.getElementById('buscarNumeroEmpleado').value = "";
            document.getElementById('BuscarNombreEmpleado').value = "";

        }
        else if (numEmpleado === '10111') {
            document.getElementById('nombreEmpleadoEncontrado').value = aryEmpleados[2];
            document.getElementById('numeroNominaEncontrado').value = aryNumEmpleado[2];
            document.getElementById('buscarNumeroEmpleado').value = "";
            document.getElementById('BuscarNombreEmpleado').value = "";

        }
        else {

            alert("El número de empleado no existe, por favor intente nuevamente");

        }
    } else if (nomEmpleado != "") {

        if (nomEmpleado === "Lourdes Terrazas Lopez") {
            document.getElementById('nombreEmpleadoEncontrado').value = aryEmpleados[0];
            document.getElementById('numeroNominaEncontrado').value = aryNumEmpleado[0];
            document.getElementById('buscarNumeroEmpleado').value = "";
            document.getElementById('BuscarNombreEmpleado').value = "";
            
        }
        else if (nomEmpleado === "Gabriel Medina Nava") {
            document.getElementById('nombreEmpleadoEncontrado').value = aryEmpleados[1];
            document.getElementById('numeroNominaEncontrado').value = aryNumEmpleado[1];
            document.getElementById('buscarNumeroEmpleado').value = "";
            document.getElementById('BuscarNombreEmpleado').value = "";
            
        }
        else if (nomEmpleado === "Eberto Fernandez Garcia") {
            document.getElementById('nombreEmpleadoEncontrado').value = aryEmpleados[2];
            document.getElementById('numeroNominaEncontrado').value = aryNumEmpleado[2];
            document.getElementById('buscarNumeroEmpleado').value = "";
            document.getElementById('BuscarNombreEmpleado').value = "";
            
        }
        else {
            
            alert("El nombre del empleado es incorrecto, por favor intente nuevamente");
            
        }
        
    }
    
}

function pausarEnvioForma() { // Fucnión para pausar el envío de la solicitud, permite mostrar un mensaje en pantalla previo al envio.
    
    guardarInformacionEmpleado();
    
    document.getElementById('msjSolicitudEnviada').style.display = 'block';
    
    setTimeout(function() {
        
        direccionamientoPaginasAplicacion();
        
    }, 4000);
    
}

function guardarInformacionEmpleado() { // Función para guardar la infrmación el empleado en la sesión. 
    
    var tipoPlazaSolicitada = document.getElementById('tipoPlazaSolicitada').value;
    var nombreDelEmpleado = document.getElementById('nombreEmpleadoEncontrado').value;
    var numeroNominaEmpleado =  document.getElementById('numeroNominaEncontrado').value;
    var motivoSustitucionSeleccionado = document.getElementById('motivoSustitucion').value;
    
    window.sessionStorage.setItem('Empleado_Encontrado', nombreDelEmpleado);
    window.sessionStorage.setItem('Numero_Empleado_Encontrado', numeroNominaEmpleado);
    window.sessionStorage.setItem('Tipo_Plaza_Solicitada', tipoPlazaSolicitada);
    window.sessionStorage.setItem('Motivo_Sust_Seleccionado', motivoSustitucionSeleccionado);
    
}

function direccionamientoPaginasAplicacion() {  // Función para "enviar" la página actual a la siguiente.

    let paginaBase = obtenerNombrePagina();

    switch (paginaBase) {

        case 'UA-Solicitud-Personal':
            window.location.href = "RH-Revision-Solicitud.html";
        break;

        case 'RH-Revision-Solicitud':
            window.location.href = "RH-Publicar-Convocatoria.html";
        break;

        case 'RH-Publicar-Convocatoria':
            window.location.href = "UA-Recepcion-Info-Candidatos.html";
        break;

        case 'UA-Revision-Observaciones-RH':
            window.location.href = "RH-Revision-Solicitud.html";
        break;

        case 'UA-Recepcion-Info-Candidatos':
            window.location.href = "UA-Seleccion-Candidato.html";
        break;

        case 'UA-Seleccion-Candidato':
            window.location.href = "Login-CVU.html";
        break;

        case 'DAIA-Revision-Probatorios':
            window.location.href = "UA-Consejo-Academico.html";
        break;

        case 'UA-Consejo-Academico':
            window.location.href = "Division-Aprobacion.html";
        break;

        case 'Division-Aprobacion':
            window.location.href = "Vicerrectoria-Aprobacion.html";
        break;

        case 'Vicerrectoria-Aprobacion':
            window.location.href = "RH-Formalizacion-Contratacion.html";
        break;

        default:
            console.log('La página solicitada no existe.');
    }

}

function mostrarInformacionSolicitud(){

    document.getElementById('plazaSolicitadaUnidadAcademica').innerHTML = window.sessionStorage.getItem('Tipo_Plaza_Solicitada');
    document.getElementById('numeroSolicitud').innerHTML = window.sessionStorage.getItem("Num_Solicitud");
    document.getElementById('NumeroCredencialEncontrado').innerHTML = window.sessionStorage.getItem('Numero_Empleado_Encontrado'); /* Empleado_Encontrado  */
    
    //document.getElementById('').innerHTML = 
    //tipoPlazaRequerida
}

function modificarSolicitud() {
    
    document.getElementById('tipoPlazaRequerido').style.display = 'none';
    document.getElementById('tdTiposPlaza').style.display = 'table-cell';
    
}